<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta Information -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Post a Job - ShangYa Consultancy</title>
  
  <!-- Stylesheets -->
  <link rel="stylesheet" href="styles/styles.css">
</head>
<body class="other-body">
  <!-- ========== HEADER SECTION ========== -->
  <header class="job-head">
    <?php
    include_once "header.inc"; 
    include_once "menu.inc";
    ?>
  </header>

  <!-- ========== MAIN CONTENT ========== -->
  <main class="form-page">
    <div class="form-container">
      <h1>Post a Job</h1>
      
      <form method="post" action="process_employer.php" novalidate="novalidate">
        <!-- Job Information -->
<!-- Job Information -->
<fieldset>
  <legend>Job Details</legend>

  <!-- Company Name -->
  <div class="form-row">
    <div class="form-group full-width">
      <label for="company-name">Company Name *</label>
      <input type="text" id="company-name" name="company-name" required>
    </div>
  </div>

  <!-- Job Title & Reference Number -->
  <div class="form-row">
    <div class="form-group full-width">
      <label for="job-title">Job Title *</label>
      <input type="text" id="job-title" name="job-title" class="job-title" required>
    </div>
  </div>

  <!-- Brief Description -->
  <div class="form-row">
    <div class="form-group full-width">
      <label for="brief-description">Brief Description *</label>
      <textarea id="brief-description" name="brief-description" rows="3" required></textarea>
    </div>
  </div>

  <!-- Work Type & Salary -->
  <div class="form-row">
    <div class="form-group">
      <label for="work-type">Work Type *</label>
      <select id="work-type" name="work-type" class="bottom-tag" required>
        <option value="">-- Select --</option>
        <option value="Part-time">Part-time</option>
        <option value="Full-time">Full-time</option>
        <option value="Internship">Internship</option>
      </select>
    </div>
    <div class="form-group pay-range-group">
              <label>Pay Range *
                <input type="text" name="salary-range" placeholder="Min - Max" required class="pay-range-input">
              </label>
            </div>
        </div>

  <!-- Hours and Location -->
  <div class="form-row">
    <div class="form-group">
      <label for="expected-hours">Expected Hours per Week *</label>
      <input type="text" id="expected-hours" name="expected-hours" required>
    </div>
    <div class="form-group">
      <label for="location">Location/Flexibility *</label>
      <input type="text" id="location" name="location" required>
    </div>
  </div>

  <!-- Reports To -->
  <div class="form-row">
    <div class="form-group full-width">
      <label for="reports-to">Reports To *</label>
      <input type="text" id="reports-to" name="reports-to" required>
    </div>
  </div>

  <!-- Responsibilities -->
  <div class="form-row">
    <div class="form-group full-width">
      <label for="responsibilities">Key Responsibilities *</label>
      <textarea id="responsibilities" name="responsibilities" rows="5" placeholder="List all key responsibilites" required></textarea>
    </div>
  </div>

  <!-- Benefits -->
  <div class="form-row">
    <div class="form-group full-width">
      <label for="benefits">Salary and Benefits *</label>
      <textarea id="benefits" name="benefits" rows="5" placeholder="List all benefits offered" required></textarea>
    </div>
  </div>

  <!-- Qualifications & Skills -->
<fieldset>
  <legend>Qualifications & Skills</legend>
  
  <div class="form-row">
    <div class="form-group full-width">
      <label for="essential-qualifications">Essential *</label>
      <textarea id="essential-qualifications" name="essential-qualifications" rows="5" placeholder="Enter essential qualifications and skills." required></textarea>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group full-width">
      <label for="preferable-qualifications">Preferable *</label>
      <textarea id="preferable-qualifications" name="preferable-qualifications" rows="5" placeholder="Enter preferable qualifications and skills."></textarea>
    </div>
  </div>
</fieldset>

</fieldset>


        <!-- Contact Information -->
        <fieldset>
          <legend>Contact Information</legend>
          <div class="form-row">
            <div class="form-group">
              <label for="email">Email *</label>
              <input type="email" id="email" name="email" placeholder="example@email.com"  required>
            </div>
            <div class="form-group">
              <label for="phone">Phone Number *</label>
              <input type="text" id="phone" name="phone" required>
            </div>
          </div>
        </fieldset>
        
        <!-- Form Buttons -->
        <div class="form-buttons">
          <input type="submit" value="Post">
          <input type="reset" value="Reset">
        </div>
      </form>
    </div>
  </main>

<?php
include_once "footer.inc";
?>
</body>
</html>