<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PHP Enhancements</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles/styles.css">
</head>
<body class="other-body">

<header class="job-head">
  <?php
  include_once "header.inc";
  include_once "menu.inc";
  ?>
</header>

<main class="main-enhance">
  <h1 id="h1-enhance">PHP Enhancements</h1>

  <!-- Login System Enhancement -->
  <div class="card-enhance">
    <details class="card-header">
      <summary>
        <h2>Login System with Account Lock</h2>
      </summary>
      <div class="card-content">
        <p>We implemented a login and logout system to restrict access to <code>manage.php</code>. User credentials are stored in a <code>users</code> table. If login fails more than 3 times, the account will be temporarily locked.</p>
        <ul>
          <li>Session is used to manage access securely.</li>
          <li>Login attempts are counted and reset after timeout.</li>
        </ul>
        <div class="image-pair">
          <figure>
            <img src="styles/images/login.png" alt="Login">
            <figcaption>Login Screen</figcaption>
          </figure>
          <figure>
            <img src="styles/images/users-table.png" alt="Users Tables">
            <figcaption>Users Table</figcaption>
          </figure>
        </div>
      </div>
    </details>
  </div>

  <!-- Manage Table Sorting -->
  <div class="card-enhance">
    <details class="card-header">
      <summary>
        <h2>Sortable Tables in manage.php</h2>
      </summary>
      <div class="card-content">
        <p>We added sorting and table-switching functionality to the admin interface in <code>manage.php</code>.</p>
        <ul>
          <li>Admins can switch between different tables: EOIs, employers, or inquiries.</li>
          <li>Each table can be sorted by selected fields.</li>
        </ul>
        <div class="image-pair">
          <figure>
            <img src="styles/images/sorting-manage.png" alt="Default Manage View">
            <figcaption>Default View of Table</figcaption>
          </figure>
          <figure>
            <img src="styles/images/sorting-result.png" alt="Sorted Manage View">
            <figcaption>Sorted Table View</figcaption>
          </figure>
        </div>
      </div>
    </details>
  </div>

  <!-- Job Filter in jobs.php -->
  <div class="card-enhance">
    <details class="card-header">
      <summary>
        <h2>Job Filtering Feature</h2>
      </summary>
      <div class="card-content">
        <p>The <code>jobs.php</code> page includes a sidebar form that allows users to filter jobs by type: full-time, part-time, or internship. The page updates to show only matching records from the database.</p>
        <ul>
          <li>Form uses <code>POST</code> to submit filter criteria.</li>
          <li>Filtered results are dynamically generated.</li>
        </ul>
        <div class="image-pair">
          <figure>
            <img src="styles/images/jobs-filter.png" alt="Filtering Job">
            <figcaption>Filtering Job</figcaption>
          </figure>
          <figure>
            <img src="styles/images/jobs-filter2.png" alt="Filtered Jobs">
            <figcaption>Filtered by Internship</figcaption>
          </figure>
        </div>
      </div>
    </details>
  </div>
</main>

<?php include_once "footer.inc"; ?>
</body>
</html>
