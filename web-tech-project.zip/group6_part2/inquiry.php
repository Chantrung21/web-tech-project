<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Inquiry - Shangya Consultancy</title>
  <link href="styles/styles.css" rel="stylesheet">
</head>
<body class="other-body">
  <!-- ========== HEADER SECTION ========== -->
  <header class="job-head">
    <?php
    include_once "header.inc"; 
    include_once "menu.inc";
    ?>
  </header>

  <!-- ========== MAIN CONTENT ========== -->
  <main class="container-inquiry">
    <section class="contact-info">
      <img src="styles/images/man-table-typing-desk.jpg" alt="Typing at Desk">
      <div class="contact-details">
        <h1>About Us</h1>
        <p><strong>Email:</strong> info@shangya.my</p>
        <p><strong>Phone:</strong> +6012-9500193</p>
        <p><strong>Address:</strong> Unit 8A, Level 1, Jalan Wan Kadir 1, Taman Tun Dr Ismail, 60000 Kuala Lumpur, Malaysia</p>
      </div>
    </section>
  
    <!-- FORM PAGE -->
    <form method="post" action="process_inquiry.php" novalidate="novalidate">
      <fieldset class="fieldset-inquiry">
        <legend>Your Name</legend>
        <div class="form-row">
          <div class="form-group">
            <label for="firstname">First Name *</label>
            <input type="text" id="firstname" name="firstname" required maxlength="20">
          </div>
          <div class="form-group">
            <label for="lastname">Last Name *</label>
            <input type="text" id="lastname" name="lastname" required maxlength="20">
          </div>
        </div>
      </fieldset>
  
      <fieldset>
        <legend>Contact Information</legend>
        <div class="form-row">
          <div class="form-group">
            <label for="email">Email *</label>
            <input type="email" id="email" name="email" placeholder="example@email.com" required>
          </div>
          <div class="form-group">
            <label for="phone">Phone Number *</label>
            <input type="text" id="phone" name="phone" required>
          </div>
        </div>
      </fieldset>
      
      <fieldset>
        <legend>Message</legend>
        <div class="text-box">
          <label for="messages">Detailed Inquiry *</label>
          <textarea id="messages" name="messages" placeholder="Type your message here..." required></textarea>
        </div>
      </fieldset>
  
      <!-- Submit and Reset Buttons -->
      <div class="form-buttons">
        <input type="submit" value="Post">
        <input type="reset" value="Reset">
      </div>
    </form>
  </main>
<?php
include_once "footer.inc";
?>
</body>
</html>