<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta Information -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ShangYa Consultancy</title>
  
  <!-- Stylesheets -->
  <link rel="stylesheet" href="styles/styles.css">
</head>
<body>
  <!-- ========== HEADER SECTION ========== -->
  <header class="hero">
    <?php
    include_once "header.inc"; 
    include_once "menu.inc";
    ?>
    <!-- UNDER BAR -->
    <section class="hero-content">
      <h2>Shangya Consultancy - Your Trusted Partner for Talent Excellence</h2>
      <h1>THE EXPERTISE YOU NEED</h1>
      <a href="#about-us">Explore Us</a>
    </section>
  </header>

  <!-- ========== MAIN CONTENT ========== -->
  <main>
    <!-- About Us Section -->
    <section id="about-us">
      <h2>Who we are? <hr></h2>
      <p class="section-text">
        ShangYa Consultancy is an innovative full-service staffing provider and agency that offers recruitment, 
        talent outsourcing, training, HR consulting, and more. We prioritize delivering top-notch service and 
        exceptional after-sales support to our clients. Our commitment lies in continuously advancing our business
        to stay up-to-date with the latest technologies and trends, all while maintaining a human touch that is never compromised.
      </p>
      <img class="about-image" src="styles/images/table.png" alt="Statistics Table">
    </section>

    <!-- What We Do Section -->
    <section id="what-we-do">
      <h2>What we do?<hr></h2>
      <p class="section-text">
        With a solid track record, our services and business approaches are enhanced by these elements. 
        This allows us to provide tailored services to our clients, helping them achieve success in their 
        ever-changing and competitive market.
      </p>
      <p class="section-text">
        By incorporating our unique market proposition with cutting-edge technology standards, we can expand our service 
        offerings across Asia and position ourselves as a preferred strategic partner for our clients.
      </p>
      <h3>Uniqueness</h3>
            <p class="section-text">
                Our pioneering solution enhances transparency across all organizational levels and 
                significantly reduces administrative burdens. Built on ShangYa Consultancy's deep industry knowledge,
                our application covers the entire talent lifecycle, from attracting top candidates to developing and retaining your workforce.
            </p>
            <p id="quote">
                "Transforming lives through pushing recruiting boundaries."
            </p>
    </section>
  </main>
<?php
include_once "footer.inc";
?>  
</body>
</html>