<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Confirmation - ShangYa Consultancy</title>
    <link rel="stylesheet" href="styles/styles.css">
</head>
<body class="other-body">
    <!-- ========== HEADER SECTION ========== -->
    <header>
        <?php
        include_once "header.inc";
        include_once "menu.inc";
        ?>
    </header>

    <!-- ========== MAIN CONTENT ========== -->
    <main class="confirmation-page">
        <div class="confirmation-card">
            <?php
            // Redirect if not POST request
            if ($_SERVER["REQUEST_METHOD"] != "POST") {
                header("Location: apply.php");
            }

            // Include database settings
            require_once("settings.php");

            // Connect to database
            $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

            if (!$conn) {
                echo "<p class='error'>Database connection failure</p>";
                echo "<p class='error'>Error number: " . mysqli_connect_errno() . "</p>";
                echo "<p class='error'>Error message: " . mysqli_connect_error() . "</p>";
                exit();
            }

            // Function to sanitize input
            function sanitise_input($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }

            // Get and sanitize form data
            $jobref     = sanitise_input($_POST["job_ref"]);
            $firstname  = sanitise_input($_POST["firstname"]);
            $lastname   = sanitise_input($_POST["lastname"]);
            $dob        = sanitise_input($_POST["dob"]);
            $gender     = isset($_POST["Gender"]) ? sanitise_input($_POST["Gender"]) : "";
            $address    = sanitise_input($_POST["address"]);
            $suburb     = sanitise_input($_POST["suburb"]);
            $state      = sanitise_input($_POST["State"]);
            $postcode   = sanitise_input($_POST["postcode"]);
            $email      = sanitise_input($_POST["email"]);
            $phone      = sanitise_input($_POST["phone"]);
            $skills     = isset($_POST["skills"]) ? $_POST["skills"] : [];
            $otherskills= sanitise_input($_POST["otherskills"]);

            // Validate input fields
            $errMsg = "";

            // Job reference validation
            if ($jobref == "") {
                $errMsg .= "<p>Job reference number is required.</p>";
            } else if (!preg_match("/^[A-Za-z0-9]{5}$/", $jobref)) {
                $errMsg .= "<p>Job reference number must be exactly 5 alphanumeric characters.</p>";
            }

            // First name validation
            if ($firstname == "") {
                $errMsg .= "<p>You must enter your first name.</p>";
            } else if (!preg_match("/^[a-zA-Z ]{1,20}$/", $firstname)) {
                $errMsg .= "<p>First name must be only letters, max 20 characters.</p>";
            }

            // Last name validation
            if ($lastname == "") {
                $errMsg .= "<p>You must enter your last name.</p>";
            } else if (!preg_match("/^[a-zA-Z ]{1,20}$/", $lastname)) {
                $errMsg .= "<p>Last name must be only letters, max 20 characters.</p>";
            }

            // Date of birth validation
            if ($dob == "") {
                $errMsg .= "<p>Date of birth is required.</p>";
            } else if (!preg_match("/^\d{2}\/\d{2}\/\d{4}$/", $dob)) {
                $errMsg .= "<p>Date of birth must be in dd/mm/yyyy format.</p>";
            } else {
                $parts = explode("/", $dob);
                if (count($parts) == 3) {
                    $day = (int)$parts[0];
                    $month = (int)$parts[1];
                    $year = (int)$parts[2];
                    $currentYear = date("Y");
                    $age = $currentYear - $year;
                    if ($age < 15 || $age > 80) {
                        $errMsg .= "<p>Age must be between 15 and 80 years.</p>";
                    }
                } else {
                    $errMsg .= "<p>Invalid date format.</p>";
                }
            }

            // Gender validation
            if ($gender != "Male" && $gender != "Female") {
                $errMsg .= "<p>You must select a gender.</p>";
            }

            // Address validation
            if ($address == "" || strlen($address) > 40) {
                $errMsg .= "<p>Address must be 1 to 40 characters.</p>";
            }

            // Suburb validation
            if ($suburb == "" || strlen($suburb) > 40) {
                $errMsg .= "<p>Suburb must be 1 to 40 characters.</p>";
            }

            // Skills validation
            if (empty($skills)) {
                $errMsg .= "<p>Please tick at least one skill.</p>";
            }

            // State validation
            $valid_states = ["Johor", "Kedah", "Kelantan", "Melaka", "Selangor", "Pahang", "Penang", "Perak", "Perlis", "Terengganu", "Sabah", "Sarawak"];
            if (!in_array($state, $valid_states)) {
                $errMsg .= "<p>Invalid state selected.</p>";
            }

            // Postcode validation
            if (!preg_match("/^\d{4}$/", $postcode)) {
                $errMsg .= "<p>Postcode must be exactly 4 digits.</p>";
            }

            // Email validation
            if ($email == "") {
                $errMsg .= "<p>Email is required.</p>";
            } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errMsg .= "<p>Invalid email format.</p>";
            }

            // Phone validation
            if ($phone == "") {
                $errMsg .= "<p>Phone number is required.</p>";
            } else if (!preg_match("/^[0-9 ]{8,12}$/", $phone)) {
                $errMsg .= "<p>Phone number must be 8 to 12 digits or spaces.</p>";
            }

            // Other skills validation
            if (in_array("Other", $skills)) {
                if (trim($otherskills) == "") {
                    $errMsg .= "<p>You selected 'Other' skill but did not specify it.</p>";
                }
            }

            // Show errors if any
            if ($errMsg != "") {
                echo "<h2>Job Application Error</h2>";
                echo $errMsg;
                echo '<p class="back-to-btn"><a href="apply.php">Go Back to Fix Errors</a></p>';
                exit();
            }

            // Create EOI table if not exists
            $tableQuery = "CREATE TABLE IF NOT EXISTS eoi (
                EOInumber INT AUTO_INCREMENT PRIMARY KEY,
                job_ref VARCHAR(5),
                firstname VARCHAR(20),
                lastname VARCHAR(20),
                dob VARCHAR(10),
                gender VARCHAR(10),
                address VARCHAR(40),
                suburb VARCHAR(40),
                state VARCHAR(20),
                postcode VARCHAR(4),
                email VARCHAR(50),
                phone VARCHAR(12),
                skill1 VARCHAR(50),
                skill2 VARCHAR(50),
                skill3 VARCHAR(50),
                skill4 VARCHAR(50),
                otherskills TEXT,
                status VARCHAR(10) DEFAULT 'New'
            );";
            $createTableResult = mysqli_query($conn, $tableQuery);
            if (!$createTableResult) {
                echo "<p>Error creating table: " . mysqli_error($conn) . "</p>";
            }

            // Prepare skills for insertion
            $skill1 = isset($skills[0]) ? sanitise_input($skills[0]) : "";
            $skill2 = isset($skills[1]) ? sanitise_input($skills[1]) : "";
            $skill3 = isset($skills[2]) ? sanitise_input($skills[2]) : "";
            $skill4 = isset($skills[3]) ? sanitise_input($skills[3]) : "";

            // Insert application into EOI table
            $insertQuery = "INSERT INTO eoi (job_ref, firstname, lastname, dob, gender, address, suburb, state, postcode, email, phone, skill1, skill2, skill3, skill4, otherskills, status)
                VALUES
                ('$jobref', '$firstname', '$lastname', '$dob', '$gender', '$address', '$suburb', '$state', '$postcode', '$email', '$phone', '$skill1', '$skill2', '$skill3', '$skill4', '$otherskills', 'New');";
            $result = mysqli_query($conn, $insertQuery);

            // Show confirmation or error
            if (!$result) {
                echo "<p class=\"wrong\">Something is wrong with $insertQuery</p>";
            } else {
                echo "<h2>Application Successful</h2>";
                echo "<p>Thank you <strong>$firstname</strong>.</p>";
                $eoi_number = mysqli_insert_id($conn);
                echo "<p>Your application has been received. Your EOInumber is: <strong>$eoi_number</strong></p>";
            }
            ?>
        </div>
    </main>
    <!-- ========== FOOTER SECTION ========== -->
    <?php include_once "footer.inc"; ?>
</body>
</html>