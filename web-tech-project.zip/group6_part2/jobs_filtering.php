<?php
require_once "settings.php";
$conn = mysqli_connect($host, $user, $pwd, $sql_db);
if (!$conn) {
  echo "Database connection failed: " . mysqli_connect_error();
  echo "<p class='error'>Error number: " . mysqli_connect_errno() . ".</p>";
  echo "<p class='error'>Error message: " . mysqli_connect_error() . ".</p>";
  exit();
}

function formatJobRef($id) {
  return str_pad($id, 5, '0', STR_PAD_LEFT);
}

function formatList($text) {
  $items = explode("\n", $text);
  $html = '';
  foreach ($items as $item) {
    if (trim($item) !== '') {
      $html .= '<li>' . trim($item) . '</li>';
    }
  }
  return $html;
}

function formatOrderedList($text) {
  $items = explode("\n", $text);
  $html = '<ol>';
  foreach ($items as $item) {
    if (trim($item) !== '') {
      $html .= '<li>' . trim($item) . '</li>';
    }
  }
  $html .= '</ol>';
  return $html;
}

$job_type = isset($_POST['job-type']) ? $_POST['job-type'] : 'all';
$job_type = mysqli_real_escape_string($conn, $job_type);

if ($job_type === 'all') {
  $sql = "SELECT * FROM jobs";
} else {
  $sql = "SELECT * FROM jobs WHERE LOWER(work_type) = LOWER('$job_type')";
}

$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Filtered Jobs - ShangYa Consultancy</title>
  <link rel="stylesheet" href="styles/styles.css"/>
</head>
<body class="other-body">
  <header class="job-head">
    <?php include_once "header.inc"; ?>
    <?php include_once "menu.inc"; ?>
  </header>

  <main class="job-main">
    <div class="job-listing">
      <?php
      if (!isset($_POST['job-type'])) {
        header("Location: jobs.php");
        exit();
      }
      else {
if (mysqli_num_rows($result) > 0) {
    echo "<h1>Jobs sorting by $job_type :</h1>";

        while ($row = mysqli_fetch_assoc($result)) {
          $job_ref = formatJobRef($row['job_ref']);
          echo '
          <section class="sec-job">
            <details class="job">
              <summary>
                <div class="job-header">
                  <h2 class="job-title">' . $row['job_title'] . '</h2>
                  <p class="ref-num">Ref: #' . $job_ref . '</p>
                  <p class="salary">' . $row['salary'] . ' RM</p>
                  <p class="bottom-tag">' . $row['work_type'] . '</p>
                </div>
              </summary>
              <div class="infor">
                <h3>Brief Descriptions:</h3>
                <p>' . nl2br($row['description']) . '</p>

                <h3>Expected Hours:</h3>
                <p>' . $row['hours'] . ' hour(s) per week</p>

                <h3>Location/Scheduling Flexibility:</h3>
                <p>' . $row['location'] . '</p>

                <h3>Salary Range:</h3>
                <p>' . $row['salary'] . ' RM</p>

                <h3>Reports To:</h3>
                <p>' . $row['reports_to'] . '</p>

                <h3>Key Responsibilities:</h3>
                ' . formatOrderedList($row['responsibilities']) . '

                <h3>Salary and Benefits:</h3>
                ' . formatOrderedList($row['benefits']) . '

                <h3>Required Qualifications, Skills, Knowledge, and Attributes:</h3>
                <ul>
                  <li><h4>Essential:</h4></li>
                  <ul>' . formatList($row['essential']) . '</ul>
                  <li><h4>Preferable:</h4></li>
                  <ul>' . formatList($row['preferable']) . '</ul>
                </ul>
              </div>
            </details>
          </section>';
        }
      } else {
        echo "<p>No jobs found for the selected type.</p>";
      }
      }
      ?>
      
      <p class="back-to-btn"><a href="jobs.php">Go Back to Jobs Listing</a></p>
    </div>
  </main>

  <?php include_once "footer.inc"; ?>
</body>
</html>
