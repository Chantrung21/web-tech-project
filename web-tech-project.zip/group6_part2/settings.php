<?php
$host = "feenix-mariadb.swin.edu.au";
$user = "s105060533";
$pwd = "210305";
$sql_db = "s105060533_db";
?>