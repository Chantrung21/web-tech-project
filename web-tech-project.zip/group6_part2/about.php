<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta Information -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About our Team</title>
  
  <!-- Stylesheets -->
  <link rel="stylesheet" href="styles/styles.css">
</head>
<body class="other-body">
  <!-- ========== HEADER SECTION ========== -->
  <header class="job-head">
    <?php
    include_once "header.inc"; 
    include_once "menu.inc";
    ?>
  </header>

  <!-- ========== MAIN CONTENT ========== -->
  <main class="main-about">
    <!-- About Our Group Section -->
    <section>
      <div class="div-head">
        <h1>About Our Group</h1>
      </div>
    </section>

    <!-- Group Information Section -->
    <div class="grid-container">
      <div class="left-sections">
        <section class="sec-inf">
          <h2>Group Information</h2>
          <dl>
            <div class="info-row">
              <dt>Group name:</dt>
              <dd>Group 6</dd>
            </div>
            <div class="info-row">
              <dt>Course:</dt>
              <dd>COS10026</dd>
            </div>
            <div class="info-row">
              <dt>Tutor's name:</dt>
              <dd>Ms. Pawani Rasaratnam</dd>
            </div>
          </dl>
        </section>

        <!-- Members and Contributions Section -->
        <section class="sec-contr">
    <h2>Members and Task Delegation</h2>
    
    <h3>The group project 1</h3>
    <dl>
        <dt>Chan Trung Dinh - J23041062</dt>
        <dd>
            Leader - Planned and divided tasks. Created index.html, jobs.html, about.html, wrote CSS for responsive design, and integrated all members' work.
        </dd>
        
        <dt>Chia Choon Yu - J25043878</dt>
        <dd>
            Member - Developed apply.html, employer.html, and enhancements.html.
        </dd>
        
        <dt>Lim Zhi Xuan - J23041018</dt>
        <dd>
            Member - Created services.html and inquiry.html, and implemented CSS animations.
        </dd>
    </dl>

    <h3>  The group project 2</h3>
    <dl>
        <dt>Chan Trung Dinh - J23041062</dt>
        <dd>
            Leader - Managed task allocation, quality control, and fixes. Developed all manage.php and did sorting enhancement, co-developed login.php (created users table, implemented 3-attempt lockout system), and changed jobs.php to dynamic post jobs from jobs data table.
        </dd>
        
        <dt>Chia Choon Yu - J25043878</dt>
        <dd>
            Member - Created jobs and eoi tables, developed process_eoi.php and process_employer.php for form submissions, and wrote enhancements.php documenting project improvements.
        </dd>
        
        <dt>Lim Zhi Xuan - J23041018</dt>
        <dd>
            Member - Created inquiry table and process_inquiry.php, co-developed login.php interface, and implemented jobs_filtering.php for job filtering functionality.
        </dd>
    </dl>
</section>
        
        
      </div>

      <!-- Group Picture Section -->
      <figure class="fig-about">
        <img src="styles/images/Group 6.png" alt="Our group picture">
        <figcaption>Group photo taken on April 24, 2025</figcaption>
      </figure>
    </div>

    <!-- Time Table Section -->
    <section class="sec-table">
      <h2>Time Table</h2>
      <table class="time-table">
        <tr>
          <th></th>
          <th>8.00</th>
          <th>9.00</th>
          <th>10.00</th>
          <th>11.00</th>
          <th>12.00</th>
          <th>13.00</th>
          <th>14.00</th>
          <th>15.00</th>
          <th>16.00</th>
          <th>17.00</th>
        </tr>
        <!-- Monday -->
        <tr>
          <th>Monday</th>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td>TNE 10006 C2 - G.L3 [Lecture]</td>
          <td>TNE 10006 C2 - G.L3 [Lecture]</td>
          <td>COS10009 C1 - G.L3 [Lecture]</td>
          <td>COS10009 C1 - G.L3 [Lecture]</td>
          <td>COS10004 C2 - A.L4.CSC2 [Practical]</td>
          <td>COS10004 C2 - A.L4.CSC2 [Practical]</td>
        </tr>
        <!-- Tuesday -->
        <tr>
          <th>Tuesday</th>
          <td></td>
          <td></td>
          <td>COS 10026 C1 - F.CUBE4&5 [Lecture]</td>
          <td>COS 10026 C1 - F.CUBE4&5 [Lecture]</td>
          <td>COS10009 C1 - G.LAB CISCO [Practical]</td>
          <td>COS10009 C1 - G.LAB CISCO [Practical]</td>
          <td></td>
          <td>TNE 10006 C3 - G.LAB CISCO [Practical]</td>
          <td>TNE 10006 C3 - G.LAB CISCO [Practical]</td>
          <td>TNE 10006 C3 - G.LAB CISCO [Practical]</td>
        </tr>
        <!-- Wednesday -->
        <tr>
          <th>Wednesday</th>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td>COS10004 C2 - F.CUBE1&2 [Practical]</td>
          <td>COS10004 C2 - F.CUBE1&2 [Practical]</td>
        </tr>
        <!-- Thursday -->
        <tr>
          <th>Thursday</th>
          <td></td>
          <td></td>
          <td>MAT2208 C1 - F.CUBE4&5 [Lecture]</td>
          <td>MAT2208 C1 - F.CUBE4&5 [Lecture]</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td>COS 10026 C1 - A.L4.CSC2 [Practical]</td>
          <td>COS 10026 C1 - A.L4.CSC2 [Practical]</td>
        </tr>
        <!-- Friday -->
        <tr>
          <th>Friday</th>
          <td></td>
          <td></td>
          <td></td>
          <td>MAT2208 C1 - F.CUBE4&5 [Lecture & Tutorial]</td>
          <td>MAT2208 C1 - F.CUBE4&5 [Lecture & Tutorial]</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </section>

    <!-- Personal Information Section -->
    <section class="member">
      <h2>Personal Information</h2>
      <div class="member-container">
        <!-- Member 1 -->
        <div class="member-card">
          <img src="styles/images/Chan Trung Dinh.png" alt="Chan Trung Dinh">
          <details>
            <summary>Chan Trung Dinh</summary>
            <ul>
              <li><strong>Hometown:</strong> Phu Yen province, Vietnam</li>
              <li><strong>Interests:</strong> Reading books, playing games, playing sports (esp volleyball and table tennis)</li>
              <li><strong>Programming skills:</strong> Newbie</li>
            </ul>
          </details>
        </div>
        <!-- Member 2 -->
        <div class="member-card">
          <img src="styles/images/Chia Choon Yu.png" alt="Chia Choon Yu">
          <details>
            <summary>Chia Choon Yu</summary>
            <ul>
              <li><strong>Hometown:</strong> Johor, Malaysia</li>
              <li><strong>Interests:</strong> Playing badminton</li>
              <li><strong>Programming skills:</strong> Newbie</li>
            </ul>
          </details>
        </div>
        <!-- Member 3 -->
        <div class="member-card">
          <img src="styles/images/Lim Zhi Xuan.png" alt="Lim Zhi Xuan">
          <details>
            <summary>Lim Zhi Xuan</summary>
            <ul>
              <li><strong>Hometown:</strong> Selangor, Malaysia</li>
              <li><strong>Interests:</strong> Playing games</li>
              <li><strong>Programming skills:</strong> Newbie</li>
            </ul>
          </details>
        </div>
      </div>
    </section>
  </main>

<?php
include_once "footer.inc";
?> 
</body>
</html>