<?php
// Start session and include settings
session_start();
require_once("settings.php");

// Connect to database
$conn = mysqli_connect($host, $user, $pwd, $sql_db);
if (!$conn) {
    echo "<p class='error'>Database connection failed.</p>";
    echo "<p class='error'>Error number: " . mysqli_connect_errno() . ".</p>";
    echo "<p class='error'>Error message: " . mysqli_connect_error() . ".</p>";
    exit();
}

// Initialize message variable
$message = "";

// Handle login form submission
if (isset($_POST["username"]) && isset($_POST["password"])) {
    // Get and sanitize input
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    // Query user from database
    $result = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");

    if ($user = mysqli_fetch_assoc($result)) {
        // Calculate time since last login attempt
        $last = strtotime($user["last_attempt_time"]);
        $minutesSinceLast = (time() - $last) / 60;

        // Check if account is locked
        if ($user["login_attempts"] >= 3 && $minutesSinceLast < 10) {
            $message = "<p class='error'>Your account is locked. Try again after 10 minutes.</p>";
        }
        // Check password
        elseif ($password === $user["password"]) {
            // Successful login: set session and reset attempts
            $_SESSION["logged_in"] = true;
            $_SESSION["username"] = $username;
            mysqli_query($conn, "UPDATE users SET login_attempts = 0 WHERE id = " . $user["id"]);
            header("Location: manage.php");
            exit();
        }
        // Incorrect password
        else {
            mysqli_query($conn, "UPDATE users SET login_attempts = login_attempts + 1, last_attempt_time = NOW() WHERE id = " . $user["id"]);
            $message = "<p class='error'>Incorrect password.</p>";
        }
    }
    // User not found
    else {
        $message = "<p class='error'>Account not found.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Login - ShangYa Consultancy</title>
    <!-- Link to CSS with cache busting -->
    <link rel="stylesheet" href="styles/styles.css">
</head>
<body class="other-body">
    <header>
        <?php 
        // Include header and menu
        include_once "header.inc"; 
        include_once "menu.inc"; 
        ?>
    </header>

    <main class="login-wrapper">
        <section class="login-box">
            <h1>Login to Management Panel</h1>
            <!-- Login form -->
            <form action="login.php" method="post">
                <div class="form-group">
                    <label for="username">Username *</label>
                    <input type="text" name="username" id="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password *</label>
                    <input type="password" name="password" id="password" required>
                </div>
                <div class="form-buttons">
                    <input type="submit" value="Login">
                </div>
            </form>
            <!-- Display message if exists -->
            <?php if ($message !== "") echo "<div class='form-message'>$message</div>"; ?>
        </section>
    </main>

    <!-- Include footer -->
    <?php include_once "footer.inc"; ?>
</body>
</html>