<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta Information -->
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Services - Shangya Consultancy</title>
  
  <!-- Stylesheets -->
  <link href="styles/styles.css" rel="stylesheet">
</head>
<body class="other-body">
  <!-- ========== HEADER SECTION ========== -->
  <header class="job-head">
    <?php
    include_once "header.inc"; 
    include_once "menu.inc";
    ?>
  </header>

  <!-- ========== MAIN CONTENT ========== -->
  <main class="services">
    <!-- Service Cards-->
    <a href="#executive" class="service">
      <img src="styles/images/research.jpg" alt="Executive Search" />
      <div class="service-content">
        <h2>Executive Search</h2>
      </div>
    </a>
    <a href="#staffing" class="service">
      <img src="styles/images/general-staffing-thumb-1960.jpg" alt="General Staffing" />
      <div class="service-content">
        <h2>General Staffing</h2>
      </div>
    </a>
    <a href="#bulk" class="service">
      <img src="styles/images/hired.jpg" alt="Bulk Hiring" />
      <div class="service-content">
        <h2>Bulk Hiring</h2>
      </div>
    </a>
    <a href="#payroll" class="service">
      <img src="styles/images/payroll-services.jpg" alt="Payroll Services" />
      <div class="service-content">
        <h2>Payroll Services</h2>
      </div>
    </a>
    <a href="#training" class="service">
      <img src="styles/images/daily-life-business-people-office.jpg" alt="Training & Development" />
      <div class="service-content">
        <h2>Training & Development</h2>
      </div>
    </a>
    <a href="#rpo" class="service">
      <img src="styles/images/ALL_tech_support_rgb_150.jpg" alt="RPO" />
      <div class="service-content">
        <h2>Recruitment Process Outsourcing (RPO)</h2>
      </div>
    </a>
  </main>

  <!-- ========== SERVICE DETAILS SECTIONS ========== -->
  <section id="executive" class="details">
    <h1>Executive Search</h1>
    <p>We offer a highly specialized, custom-tailored recruitment service designed to
      cater to the unique demands of diverse niche industry roles in a fiercely competitive market.
      This encompasses recruiting top-tier C-level executives to identifying
      and securing the most exceptional talents available in the marketplace.

      <section id="Focus">
      <h2>Our Focus:</h2>
      </section>

      <ul class="Focus-list">
        <li>The recruitment of the most highly qualified candidates.</li>
        <li>Centers on the meticulous sourcing</li>
        <li>Comprehensive screening</li>
        <li>Rigorous filtering</li>
      </ul>

    </p>
  </section>

  <section id="staffing" class="details">
    <h1>General Staffing</h1>
    <p>We provide a comprehensive recruitment service in which we actively assist and consult with our cilents
      in the recruitment of junior to mid-level staff. We recognize the essential role that mid-level positions
      play in ensuring the overall operational efficiency of a business across all departments and divisions.
      Our services encompass not only identifying and hiring experienced mid-level professionals
      but also extend to sourcing and recruiting talented fresh graduates, contributing to the growth and vitality of your workforce.</p>
  </section>

  <section id="bulk" class="details">
    <h1>Bulk Hiring</h1>
    <p>   We offer a specialized service designed for the rapid onboarding
      of a substantial number of candidates within a specified timeframe.
      This service is particularly valuable for companies facing high staff turnover
      which often occurs in industries characterized by specific job demands.
      Ensuring the timely and efficient replenishment of their workforce.
      It is especially relevant for businesses in sectors such as:</p>

        <ol class="bulk-list">
          <li>Business Process Outsourcing <strong>(BPO)</strong></li>
          <li>Retail, food and beverage <strong>(F&B)</strong></li>
          <li>General Labor</li>
        </ol>

  </section>

  <section id="payroll" class="details">
    <h1>Payroll Services</h1>
    <p>We offer Payroll Services that encompass precise and timely employee compensation calculations and disbursements,
      meticulous benefits and deductions management, and compliance with complex tax regulations.
      We provide invaluable insights into workforce costs and performance,
      enabling informed decisions on resource allocation and financial management. Our services
      prioritize employee satisfaction and regulatory adherence, contributing to overall
      operational efficiency while allowing clients to focus on their core activities</p>
  </section>

  <section id="training" class="details">
    <h1>Training & Development</h1>
    <p>Our Staff Training & Development services are a tailored set of solutions dedicated to fostering the growth and
      adaptability of our clients' workforce. These services encompass customized
      training programs, skill enrichment, and talent development initiatives,
      ensuring that our clients' staff members are equipped with the knowledge and competencies
      necessary for professional advancement in a dynamic business environment.</p>
  </section>

  <section id="rpo" class="details">
    <h1>Recruitment Process Outsourcing (RPO)</h1>
    <p>We provide a strategic solution aimed at streamlining and optimizing our clients' recruitment procedures.
      These services encompass a comprehensive approach, from candidate sourcing and screening to interviewing
      and selection. Our RPO services effectively handle the end-to-end
      recruitment process, allowing our clients to focus on core business activities. We prioritize the
      identification and acquisition of top talent to meet our clients' staffing needs efficiently and with
      a human touch, ensuring the right candidates are in the right roles to support their business growth.</p>
  </section>

<?php
include_once "footer.inc";
?>
</body>
</html>