<?php
require_once "settings.php";

// Block direct access via URL
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: inquiry.php");
    exit;
}

// Sanitize function
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Connect to DB
$conn = @mysqli_connect($host, $user, $pwd, $sql_db);
if (!$conn) {
    die("<p>Database connection failed.</p>");
}

// Sanitize and collect input
$firstname = isset($_POST["firstname"]) ? sanitize_input($_POST["firstname"]) : "";
$lastname  = isset($_POST["lastname"]) ? sanitize_input($_POST["lastname"]) : "";
$email     = isset($_POST["email"]) ? sanitize_input($_POST["email"]) : "";
$phone     = isset($_POST["phone"]) ? sanitize_input($_POST["phone"]) : "";
$messages  = isset($_POST["messages"]) ? sanitize_input($_POST["messages"]) : "";

$errors = [];

// Validate input
if (!preg_match("/^[a-zA-Z ]{1,20}$/", $firstname)) $errors[] = "Invalid first name.";
if (!preg_match("/^[a-zA-Z]{1,20}$/", $lastname))  $errors[] = "Invalid last name.";
if (!filter_var($email, FILTER_VALIDATE_EMAIL))    $errors[] = "Invalid email format.";
if (!preg_match("/^[0-9\-\+\s]{7,20}$/", $phone))   $errors[] = "Invalid phone number.";
if (empty($messages))                              $errors[] = "Message cannot be empty.";

// Create table if it doesn't exist
$table_sql = "CREATE TABLE IF NOT EXISTS inquiry (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(20),
    lastname VARCHAR(20),
    email VARCHAR(100),
    phone VARCHAR(20),
    messages TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
mysqli_query($conn, $table_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Confirmation - ShangYa Consultancy</title>
  <link rel="stylesheet" href="styles/styles.css">
</head>
<body class="other-body">
  <!-- ========== HEADER SECTION ========== -->
  <header class="job-head">
    <?php
      include_once "header.inc";
      include_once "menu.inc";
    ?>
  </header>

  <!-- ========== MAIN CONTENT ========== -->
  <main class="confirmation-page">
    <?php
    // Show validation errors if any
    if (!empty($errors)) {
        echo "<section class='confirmation-box'>";
        echo "<h1>Validation Errors:</h1>";
        foreach ($errors as $error) {
            echo "<p>$error</p>";
        }
        echo "<a href='inquiry.php' class='btn'>Go Back</a>";
        echo "</section>";
        mysqli_close($conn);
        exit;
    }

    // Insert data using prepared statement
    $query = "INSERT INTO inquiry (firstname, lastname, email, phone, messages)
              VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sssss", $firstname, $lastname, $email, $phone, $messages);

    echo "<section class='confirmation-box'>";
    if (mysqli_stmt_execute($stmt)) {
        echo "<h2>Thank you, " . htmlspecialchars($firstname) . "!</h2>";
        echo "<p>Your inquiry has been successfully submitted.</p>";
    } else {
        echo "<p>There was a problem submitting your inquiry. Please try again later.</p>";
    }
    echo "<a href='inquiry.php' class='btn'>Return to Inquiry Form</a>";
    echo "</section>";

    mysqli_close($conn);
    ?>
  </main>

  <!-- ========== FOOTER SECTION ========== -->
  <?php include_once "footer.inc"; ?>
</body>
</html>