<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="styles/styles.css">
    <title>Confirmation - ShangYa Consultancy</title>
</head>
<body class="other-body">
    <!-- ========== HEADER SECTION ========== -->
    <header>
        <?php
        include_once "header.inc";
        include_once "menu.inc";
        ?>
    </header>

    <!-- ========== MAIN CONTENT ========== -->
    <main class="confirmation-page">
        <div class="confirmation-card">
            <?php
            // Redirect if not POST request
            if ($_SERVER["REQUEST_METHOD"] != "POST") {
                header("Location: employer.php");
            }

            // Include database settings
            require_once("settings.php");

            // Connect to database
            $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

            if (!$conn) {
                echo "<p class='error'>Database connection failed</p>";
                echo "<p class='error'>Error number: " . mysqli_connect_errno() . "</p>";
                echo "<p class='error'>Error message: " . mysqli_connect_error() . "</p>";
                exit();
            }

            // Sanitize input
            function sanitise_input($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }


            // Get and sanitize form data
            $company        = sanitise_input($_POST["company-name"]);
            $title          = sanitise_input($_POST["job-title"]);
            $description    = sanitise_input($_POST["brief-description"]);
            $worktype       = sanitise_input($_POST["work-type"]);
            $salary         = sanitise_input($_POST["salary-range"]);
            $hours          = sanitise_input($_POST["expected-hours"]);
            $location       = sanitise_input($_POST["location"]);
            $reportsTo      = sanitise_input($_POST["reports-to"]);
            $responsibilities = sanitise_input($_POST["responsibilities"]);
            $benefits       = sanitise_input($_POST["benefits"]);
            $essential      = sanitise_input($_POST["essential-qualifications"]);
            $preferable     = sanitise_input($_POST["preferable-qualifications"]);
            $email          = sanitise_input($_POST["email"]);
            $phone          = sanitise_input($_POST["phone"]);

            // Validate inputs
            $errMsg = "";
            if ($company == "") $errMsg .= "<p>Company name is required.</p>";
            if ($title == "") $errMsg .= "<p>Job title is required.</p>";
            if ($description == "") $errMsg .= "<p>Brief description is required.</p>";
            if ($worktype == "") $errMsg .= "<p>Work type is required.</p>";
            if ($salary == "") $errMsg .= "<p>Salary range is required.</p>";
            if ($hours == "") {
                $errMsg .= "<p>Expected hours is required.</p>";
            } else if (!is_numeric($hours) || $hours <= 0 || $hours > 60) {
                $errMsg .= "<p>Expected hours must be a valid number from 0 to 60.</p>";
            }
            if ($location == "") $errMsg .= "<p>Location is required.</p>";
            if ($reportsTo == "") $errMsg .= "<p>Reports to field is required.</p>";
            if ($responsibilities == "") $errMsg .= "<p>Responsibilities are required.</p>";
            if ($benefits == "") $errMsg .= "<p>Benefits are required.</p>";
            if ($essential == "") $errMsg .= "<p>Essential qualifications are required.</p>";
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errMsg .= "<p>Invalid email format.</p>";
            if (!preg_match("/^[0-9 ]{8,12}$/", $phone)) $errMsg .= "<p>Phone must be 8-12 digits or spaces.</p>";

            if ($errMsg != "") {
                echo "<h2>Job Posting Error</h2>";
                echo $errMsg;
                echo '<p class="back-to-btn"><a href="employer.php">Go Back to Fix Errors</a></p>';
                exit();
            }

            // Create table if it doesn't exist
            $tableQuery = "CREATE TABLE IF NOT EXISTS jobs (
                job_ref INT AUTO_INCREMENT PRIMARY KEY,
                company VARCHAR(100),
                job_title VARCHAR(100),
                description TEXT,
                work_type VARCHAR(20),
                salary VARCHAR(30),
                hours VARCHAR(20),
                location VARCHAR(100),
                reports_to VARCHAR(100),
                responsibilities TEXT,
                benefits TEXT,
                essential TEXT,
                preferable TEXT,
                email VARCHAR(100),
                phone VARCHAR(15)
            );";
            $createResult = mysqli_query($conn, $tableQuery);
            if (!$createResult) {
                echo "<p>Error creating table: " . mysqli_error($conn) . "</p>";
                exit();
            }

            // Insert into table
            $insertQuery = "INSERT INTO jobs 
                (company, job_title, description, work_type, salary, hours, location, reports_to, responsibilities, benefits, essential, preferable, email, phone)
                VALUES
                ('$company', '$title', '$description', '$worktype', '$salary', '$hours', '$location', '$reportsTo', '$responsibilities', '$benefits', '$essential', '$preferable', '$email', '$phone');";

            $result = mysqli_query($conn, $insertQuery);

            if (!$result) {
                echo "<p class=\"wrong\">Something is wrong with $insertQuery</p>";
                exit();
            } else {

                echo "<h2>Job Posted Successfully</h2>";
                echo "<p>Job <strong>$title</strong> at <strong>$company</strong> has been posted.</p>";
            }
            ?>
        </div>
    </main>

    <!-- ========== FOOTER SECTION ========== -->
    <?php include_once "footer.inc"; ?>
</body>
</html>
