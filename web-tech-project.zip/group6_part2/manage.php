<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Information -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management - ShangYa Consultancy</title>
    <!-- Stylesheets -->
    <link rel="stylesheet" href="styles/styles.css">
</head>
<body class="other-body">

    <!-- ========== HEADER SECTION ========== -->
    <header class="job-head">
        <?php
        session_start();
        include_once "header.inc";
        include_once "menu.inc";

        // Redirect to login if not logged in
        if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !== true) {
            header("Location: login.php");
            exit();
        }

        // Handle logout
        if (isset($_POST["logout"])) {
            session_destroy();
            header("Location: login.php");
            exit();
        }

        $username = $_SESSION["username"];
        ?>
    </header>

    <!-- ========== MAIN CONTENT ========== -->
    <main class="management-main">
        <div class="management-container">
            <h1>Expression of Interest Management</h1>
            <h2>Logged in as: <strong><?php echo htmlspecialchars($username); ?></strong></h2>

            <!-- ===== Display All EOIs Form ===== -->
            <form action="manage.php" method="post" class="management-form" novalidate="novalidate">
                <fieldset>
                    <legend>Display All Tables</legend>
                    <div class="form-group">
                        <p>View all submitted expressions of interest in the database.</p>
                        <p>EOI table can be sorted by EOInumber, job reference, first name, last name, gender or status.</p>
                        <p>Job postings can be sorted by job reference.</p>
                        <p>Inquiries can be sorted by inquiry ID, first name or last name.</p>
                        <label for="type-table" id="type-table">Select Table to View:</label>
                        <select id="type-table" name="type-table" required>
                            <option value="eoi">Applications (EOI)</option>
                            <option value="jobs">Job Postings (Employer)</option>
                            <option value="inquiry">Inquiries</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="sort-by">Sort By:</label>
                        <select id="sort-by" name="sort-by" required>
                            <option value="EOInumber">EOI Number</option>
                            <option value="job_ref">Job Reference</option>
                            <option value="firstname">First Name</option>
                            <option value="lastname">Last Name</option>
                            <option value="gender">Gender</option>
                            <option value="id">Inquiry ID</option>
                            <option value="status">Status</option>
                        </select>
                    </div>
                    <input type="submit" name="sorting" value="Sorting" class="management-btn">
                    <input type="submit" name="show_all" value="Show All" class="management-btn">
                </fieldset>
            </form>

            <?php
            // ===== Display All EOIs Logic =====
            if (isset($_POST['show_all'])) {
                require_once("settings.php");
                $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

                if (!$conn) {
                    echo "<p class='error'>Database connection failed.</p>";
                    echo "<p class='error'>Error number: " . mysqli_connect_errno() . ".</p>";
                    echo "<p class='error'>Error message: " . mysqli_connect_error() . ".</p>";
                } else {
                    function print_table($conn, $table_name, $title) {
                        $query = "SELECT * FROM `$table_name`";
                        $result = mysqli_query($conn, $query);

                        if (!$result || mysqli_num_rows($result) == 0) {
                            echo "<h2>$title</h2><p class='error'>No records found.</p>";
                            return;
                        }

                        echo "<h2>$title</h2>";
                        echo "<div class='table-scroll'><table class='management-table'>";
                        echo "<tr>";
                        while ($field = mysqli_fetch_field($result)) {
                            echo "<th>" . htmlspecialchars($field->name) . "</th>";
                        }
                        echo "</tr>";
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            foreach ($row as $value) {
                                echo "<td>" . htmlspecialchars($value) . "</td>";
                            }
                            echo "</tr>";
                        }
                        echo "</table></div>";
                    }

                    print_table($conn, "eoi", "Applications (EOI)");
                    print_table($conn, "jobs", "Job Postings (Employer)");
                    print_table($conn, "inquiry", "Inquiries");

                    mysqli_close($conn);
                }
            }

            // ===== Sorting Logic =====
            if (isset($_POST['sorting'])) {
                require_once("settings.php");
                $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

                if (!$conn) {
                    echo "<p class='error'>Database connection failed.</p>";
                    echo "<p class='error'>Error number: " . mysqli_connect_errno() . ".</p>";
                    echo "<p class='error'>Error message: " . mysqli_connect_error() . ".</p>";
                } else {
                    $table = isset($_POST['type-table']) ? $_POST['type-table'] : '';
                    $sort_by = isset($_POST['sort-by']) ? $_POST['sort-by'] : '';

                    $allowed_sort_fields = [
                        'eoi' => ['EOInumber', 'job_ref', 'firstname', 'lastname', 'gender', 'status'],
                        'jobs' => ['job_ref'],
                        'inquiry' => ['id', 'firstname', 'lastname']
                    ];

                    if (!array_key_exists($table, $allowed_sort_fields)) {
                        echo "<p class='error'>Invalid table selected.</p>";
                    } else if (!in_array($sort_by, $allowed_sort_fields[$table])) {
                        echo "<p class='error'>Invalid sort field for $table table.</p>";
                    } else {
                        $query = "SELECT * FROM `$table` ORDER BY `$sort_by`";
                        $result = mysqli_query($conn, $query);

                        echo "<h2>Sorted <strong>$table</strong> by <strong>$sort_by:</strong></h2>";

                        if (!$result || mysqli_num_rows($result) == 0) {
                            echo "<p class='error'>No records found in <strong>$table</strong>.</p>";
                        } else {
                            echo "<div class='table-scroll'><table class='management-table'>";
                            echo "<tr>";
                            while ($field = mysqli_fetch_field($result)) {
                                echo "<th>" . htmlspecialchars($field->name) . "</th>";
                            }
                            echo "</tr>";
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                foreach ($row as $value) {
                                    echo "<td>" . htmlspecialchars($value) . "</td>";
                                }
                                echo "</tr>";
                            }
                            echo "</table></div>";
                        }
                    }
                    mysqli_close($conn);
                }
            }
            ?>

            <!-- ===== Search by Reference Number Form ===== -->
            <form method="post" action="manage.php" class="management-form" novalidate="novalidate">
                <fieldset>
                    <legend>Search by Reference Number</legend>
                    <div class="form-group">
                        <label for="refnum">Reference Number *</label>
                        <input type="text" id="refnum" name="refnum"
                               pattern="[A-Za-z0-9]{5}"
                               title="Must be exactly 5 alphanumeric characters"
                               placeholder="Enter 5-character reference"
                               required>
                        <small>Format: 5 letters/numbers (e.g. AB123)</small>
                    </div>
                    <input type="submit" name="search_ref" value="Search" class="management-btn">
                </fieldset>
            </form>

            <?php
            // ===== Search by Reference Number Logic =====
            if (isset($_POST['search_ref'])) {
                require_once("settings.php");
                $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

                if (!$conn) {
                    echo "<p class='error'>Database connection failed.</p>";
                    echo "<p class='error'>Error number: " . mysqli_connect_errno() . ".</p>";
                    echo "<p class='error'>Error message: " . mysqli_connect_error() . ".</p>";
                } else {
                    $ref = trim($_POST['refnum']);
                    $ref = mysqli_real_escape_string($conn, $ref);

                    if (!preg_match("/^[A-Za-z0-9]{5}$/", $ref)) {
                        echo "<p class='error'>Invalid reference number format.</p>";
                    } else {
                        $query = "SELECT * FROM eoi WHERE job_ref = '$ref'";
                        $result = mysqli_query($conn, $query);

                        echo "<h2>Search Result for Job Reference: $ref</h2>";

                        if (!$result || mysqli_num_rows($result) == 0) {
                            echo "<p class='error'>No applications found with reference number <strong>$ref</strong>.</p>";
                        } else {
                            echo "<div class='table-scroll'><table class='management-table'>";
                            echo "<tr>";
                            while ($field = mysqli_fetch_field($result)) {
                                echo "<th>" . htmlspecialchars($field->name) . "</th>";
                            }
                            echo "</tr>";
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                foreach ($row as $value) {
                                    echo "<td>" . htmlspecialchars($value) . "</td>";
                                }
                                echo "</tr>";
                            }
                            echo "</table></div>";
                        }
                    }
                    mysqli_close($conn);
                }
            }
            ?>

            <!-- ===== Search by Applicant Name Form ===== -->
            <form method="post" action="manage.php" class="management-form" novalidate="novalidate">
                <fieldset>
                    <legend>Search by Applicant Name</legend>
                    <div class="form-group">
                        <label for="firstname">First Name *</label>
                        <input type="text" id="firstname" name="firstname"
                               pattern="[A-Za-z ]+"
                               title="Letters and spaces only"
                               maxlength="20"
                               placeholder="Applicant's first name"
                               required>
                    </div>
                    <div class="form-group">
                        <label for="lastname">Last Name *</label>
                        <input type="text" id="lastname" name="lastname"
                               pattern="[A-Za-z ]+"
                               title="Letters and spaces only"
                               maxlength="20"
                               placeholder="Applicant's last name"
                               required>
                    </div>
                    <input type="submit" name="search_name" value="Search" class="management-btn">
                </fieldset>
            </form>

            <?php
            // ===== Search by Applicant Name Logic =====
            if (isset($_POST['search_name'])) {
                require_once("settings.php");
                $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

                if (!$conn) {
                    echo "<p class='error'>Database connection failed.</p>";
                    echo "<p class='error'>Error number: " . mysqli_connect_errno() . ".</p>";
                    echo "<p class='error'>Error message: " . mysqli_connect_error() . ".</p>";
                } else {
                    $fname = trim($_POST['firstname']);
                    $lname = trim($_POST['lastname']);
                    $fname = mysqli_real_escape_string($conn, $fname);
                    $lname = mysqli_real_escape_string($conn, $lname);

                    if (empty($fname) && empty($lname)) {
                        echo "<p class='error'>You must enter at least a first name or a last name.</p>";
                    } else if ((!empty($fname) && !preg_match("/^[A-Za-z ]+$/", $fname)) ||
                               (!empty($lname) && !preg_match("/^[A-Za-z ]+$/", $lname))) {
                        echo "<p class='error'>Invalid name format. Only letters and spaces are allowed.</p>";
                    } else {
                        $conditions = [];
                        if (!empty($fname)) $conditions[] = "firstname LIKE '%$fname%'";
                        if (!empty($lname)) $conditions[] = "lastname LIKE '%$lname%'";
                        $where = implode(" AND ", $conditions);
                        $query = "SELECT * FROM eoi WHERE $where";
                        $result = mysqli_query($conn, $query);

                        echo "<h2>Search Result for: " . htmlspecialchars("$fname $lname") . "</h2>";

                        if (!$result || mysqli_num_rows($result) == 0) {
                            echo "<p class='error'>No applications found for <strong>" . htmlspecialchars("$fname $lname") . "</strong>.</p>";
                        } else {
                            echo "<div class='table-scroll'><table class='management-table'>";
                            echo "<tr>";
                            while ($field = mysqli_fetch_field($result)) {
                                echo "<th>" . htmlspecialchars($field->name) . "</th>";
                            }
                            echo "</tr>";
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                foreach ($row as $value) {
                                    echo "<td>" . htmlspecialchars($value) . "</td>";
                                }
                                echo "</tr>";
                            }
                            echo "</table></div>";
                        }
                    }
                    mysqli_close($conn);
                }
            }
            ?>

            <!-- ===== Delete by Reference Number Form ===== -->
            <form method="post" action="manage.php" class="management-form" novalidate="novalidate">
                <fieldset>
                    <legend>Delete Applications</legend>
                    <div class="form-group">
                        <label for="delete_refnum">Reference Number *</label>
                        <input type="text" id="delete_refnum" name="delete_refnum"
                               pattern="[A-Za-z0-9]{5}"
                               title="Must be exactly 5 alphanumeric characters"
                               placeholder="Enter reference to delete"
                               required>
                        <small>Warning: This will delete all applications with this reference</small>
                    </div>
                    <input type="submit" name="delete_ref" value="Delete" class="management-btn">
                </fieldset>
            </form>

            <?php
            // ===== Delete by Reference Number Logic =====
            if (isset($_POST['delete_ref'])) {
                require_once("settings.php");
                $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

                if (!$conn) {
                    echo "<p class='error'>Database connection failed.</p>";
                    echo "<p class='error'>Error number: " . mysqli_connect_errno() . ".</p>";
                    echo "<p class='error'>Error message: " . mysqli_connect_error() . ".</p>";
                } else {
                    $ref = trim($_POST['delete_refnum']);
                    $ref = mysqli_real_escape_string($conn, $ref);

                    if (!preg_match("/^[A-Za-z0-9]{5}$/", $ref)) {
                        echo "<p class='error'>Invalid job reference format. Must be exactly 5 letters or numbers.</p>";
                    } else {
                        $checkQuery = "SELECT COUNT(*) AS count FROM eoi WHERE job_ref = '$ref'";
                        $checkResult = mysqli_query($conn, $checkQuery);
                        $row = mysqli_fetch_assoc($checkResult);

                        if ($row['count'] == 0) {
                            echo "<p class='error'>No applications found with reference number <strong>$ref</strong>.</p>";
                        } else {
                            $deleteQuery = "DELETE FROM eoi WHERE job_ref = '$ref'";
                            $deleteResult = mysqli_query($conn, $deleteQuery);

                            if ($deleteResult) {
                                echo "<p class='success'>Deleted {$row['count']} application(s) with reference <strong>$ref</strong>.</p>";
                            } else {
                                echo "<p class='error'>Failed to delete applications. Please try again.</p>";
                            }
                        }
                    }
                    mysqli_close($conn);
                }
            }
            ?>

            <!-- ===== Update EOI Status Form ===== -->
            <form method="post" action="manage.php" class="management-form" novalidate="novalidate">
                <fieldset>
                    <legend>Update Application Status</legend>
                    <div class="form-group">
                        <label for="eoinum">Application ID *</label>
                        <input type="text" id="eoinum" name="eoinum"
                               pattern="[0-9]+"
                               title="Numbers only"
                               placeholder="Enter application ID"
                               required>
                    </div>
                    <div class="form-group">
                        <label for="status">New Status *</label>
                        <select id="status" name="status" required>
                            <option value="">Select status</option>
                            <option value="New">New</option>
                            <option value="Current">Current</option>
                            <option value="Final">Final</option>
                        </select>
                    </div>
                    <input type="submit" name="update_status" value="Update Status" class="management-btn">
                </fieldset>
            </form>

            <?php
            // ===== Update EOI Status Logic =====
            if (isset($_POST['update_status'])) {
                require_once("settings.php");
                $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

                if (!$conn) {
                    echo "<p class='error'>Database connection failed.</p>";
                    echo "<p class='error'>Error number: " . mysqli_connect_errno() . ".</p>";
                    echo "<p class='error'>Error message: " . mysqli_connect_error() . ".</p>";
                } else {
                    $eoinum = trim($_POST['eoinum']);
                    $status = trim($_POST['status']);
                    $eoinum = mysqli_real_escape_string($conn, $eoinum);
                    $status = mysqli_real_escape_string($conn, $status);

                    if (!preg_match("/^[0-9]+$/", $eoinum)) {
                        echo "<p class='error'>Invalid Application ID. Must be a number.</p>";
                    } else if (!in_array($status, ['New', 'Current', 'Final'])) {
                        echo "<p class='error'>Invalid status selected.</p>";
                    } else {
                        $checkQuery = "SELECT * FROM eoi WHERE EOInumber = $eoinum";
                        $checkResult = mysqli_query($conn, $checkQuery);

                        if (!$checkResult || mysqli_num_rows($checkResult) == 0) {
                            echo "<p class='error'>No application found with ID <strong>$eoinum</strong>.</p>";
                        } else {
                            $updateQuery = "UPDATE eoi SET status = '$status' WHERE EOInumber = $eoinum";
                            $updateResult = mysqli_query($conn, $updateQuery);

                            if ($updateResult) {
                                echo "<p class='success'>Application ID <strong>$eoinum</strong> updated to status <strong>$status</strong>.</p>";
                            } else {
                                echo "<p class='error'>Failed to update application status.</p>";
                            }
                        }
                    }
                    mysqli_close($conn);
                }
            }
            ?>

            <!-- ===== Logout Button ===== -->
            <form method="post">
                <input type="submit" name="logout" value="Logout" class="management-btn">
            </form>
        </div>
    </main>

    <!-- ========== FOOTER SECTION ========== -->
    <?php include_once "footer.inc"; ?>
</body>
</html>