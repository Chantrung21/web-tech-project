<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta Information -->
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>YAHR</title>
  
  <!-- Stylesheets -->
  <link href="styles/styles.css" rel="stylesheet">
</head>
<body class="other-body">
  <!-- ========== HEADER SECTION ========== -->
  <header class="job-head">
    <?php
    include_once "header.inc"; 
    include_once "menu.inc";
    ?>
  </header>

  <!-- ========== MAIN CONTENT ========== -->
 <main>
    <section class = "hero-yahr">
        <div class = "left-side">
            <div class = "yahr-logo-containter">
               <img src = "styles/images/YAHR.png" alt = "YARH Logo">
            </div>
            <p class = "intr">Developed by ShangYa Consultancy</p>
            <p class = "intr">Human Resource Management Application</p>
            <a href="#our-mission" class = "yahr-btn">Explore More</a>
        </div>
        <div class = "right-side">
            <img src = "styles/images/YAHR-interface.png" alt = "YAHR Interface">
        </div>
    </section>

    <section class = "our-mission" id = "our-mission">
        <div class = "mission">
            <h1>Our Mission</h1>
            <p>   At ShangYa, we believe that attitude determines altitude. YAHR is designed to:</p>
            <ul class = "mission-list">
                <li><div class = "circle-number">1</div>Shift focus from traditional KPIs to attitude and behavior assessments.</li>
                <li><div class = "circle-number">2</div>Bridge the gap between employers and employees through meaningful engagement.</li>
                <li><div class = "circle-number">3</div>Foster personal growth via regular feedback and development tools.</li>
            </ul>
        </div>
        <div class = "img-decoration">
            <img src = "styles/images/YAHR-mission.png" alt = "YAHR Mission">
        </div>
    </section>

    <section class="key-features">
  <h2>Key Features</h2>
  <div class="feature-wrapper">
    <div class="feature">
      <div class="img-decor">
        <img src="styles/images/feature1.png" alt="YAHR Feature 1">
      </div>
      <div class="content-feature">
        <h3>Feedback:</h3>
        <p>Facilitate comprehensive evaluations from peers and managers.</p>
      </div>
    </div>
    <div class="feature">
      <div class="img-decor">
        <img src="styles/images/feature2.png" alt="YAHR Feature 2">
      </div>
      <div class="content-feature">
        <h3>Personalized Profiles:</h3>
        <p>Dedicated profile showcasing their name, contact details, and essential HR information.</p>
      </div>
    </div>
    <div class="feature">
      <div class="img-decor">
        <img src="styles/images/feature3.png" alt="YAHR Feature 3">
      </div>
      <div class="content-feature">
        <h3>Earned Salary Access:</h3>
        <p>Employees must activate their account via email to access early salary withdrawals, limited to 50% of their earned daily wages.</p>
      </div>
    </div>
    <div class="feature">
      <div class="img-decor">
        <img src="styles/images/feature4.png" alt="YAHR Feature 4">
      </div>
      <div class="content-feature">
        <h3>Attendance Tracking:</h3>
        <p>Setup OR device (Android & IOS). Scan to check in and check out.</p>
      </div>
    </div>
  </div>
</section>

<section class = "benefits">
    <div class = "benefit-container">
        <div class = "img-benefit-decor">
            <img src = "styles/images/benefits.png" alt = "Image Decoration">
        </div>
        <div class = "benefit-content">
            <h2>Why Choose YAHR?</h2>
            <h3>For Employers:</h3>
            <ul>
                <li>Enhance recuitment by identifying candidates who align with company values.</li>
                <li>Reduce turnover by fostering a positive work environment.</li>
            </ul>
            <h3>For Employees:</h3>
            <ul>
                <li>Receive constructive feedback to aid personal and professional growth.</li>
                <li>Increase job satisfaction throguh recognition of positive behaviors.</li>
            </ul>
        </div>
    </div>
    <div class = "download">
        <a href = "https://apps.apple.com/my/app/yahr/id6471645059"><img src = "styles/images/ios.png" alt = "IOS Download"></a>
        <a href = "https://play.google.com/store/apps/details?id=com.sypay.flutter"><img src = "styles/images/android.png" alt = "Android Download"></a>
    </div>
</section>

 </main> 



<?php
include_once "footer.inc";
?>
</body>
</html>