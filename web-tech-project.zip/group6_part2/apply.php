<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta Information -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Upload Resume - ShangYa Consultancy</title>
  
  <!-- Stylesheets -->
  <link rel="stylesheet" href="styles/styles.css">
</head>
<body class="other-body">
  <!-- ========== HEADER SECTION ========== -->
  <header class="job-head">
    <?php
    include_once "header.inc"; 
    include_once "menu.inc";
    ?>
  </header>

  <!-- ========== MAIN CONTENT ========== -->
  <main class="form-page">
    <div class="form-container">
      <h1>Job Application Form</h1>
      
      <form method="post" action="process_eoi.php" novalidate="novalidate">
        <!-- Personal Information Section -->
        <fieldset>
          <legend>Personal Information</legend>
          <div class="form-row">
            <div class="form-group">
              <label for="job_ref">Job Reference Number *</label>
              <input type="text" id="job_ref" name="job_ref" required pattern="[A-Za-z0-9]{5}">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="firstname">First Name *</label>
              <input type="text" id="firstname" name="firstname" required maxlength="20">
            </div>
            <div class="form-group">
              <label for="lastname">Last Name *</label>
              <input type="text" id="lastname" name="lastname" required maxlength="20">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="dob">Date of Birth *</label>
              <input type="text" id="dob" name="dob" required placeholder="dd/mm/yyyy" pattern="\d{2}/\d{2}/\d{4}">
            </div>
            <div class="form-group">
              <legend>Gender *</legend>
              <div class="radio-group">
                <label><input type="radio" name="Gender" value="Male" required> Male</label>
                <label><input type="radio" name="Gender" value="Female"> Female</label>
              </div>
            </div>
          </div>
        </fieldset>
        
        <!-- Contact Information Section -->
        <fieldset>
          <legend>Contact Information</legend>
          <div class="form-row">
            <div class="form-group full-width">
              <label for="address">Street Address *</label>
              <input type="text" id="address" name="address" required maxlength="40">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="suburb">Suburb/Town *</label>
              <input type="text" id="suburb" name="suburb" required maxlength="40">
            </div>
            <div class="form-group">
              <label for="state">State *</label>
              <select id="state" name="State" required>
                <option value="">Select State</option>
                <option value="Johor">Johor</option>
                <option value="Kedah">Kedah</option>
                <option value="Kelantan">Kelantan</option>
                <option value="Melaka">Melaka</option>
                <option value="Selangor">Selangor</option>
                <option value="Pahang">Pahang</option>
                <option value="Penang">Penang</option>
                <option value="Perak">Perak</option>
                <option value="Perlis">Perlis</option>
                <option value="Terengganu">Terengganu</option>
                <option value="Sabah">Sabah</option>
                <option value="Sarawak">Sarawak</option>
                <!-- Other state options -->
              </select>
            </div>
            <div class="form-group">
              <label for="postcode">Postcode *</label>
              <input type="text" id="postcode" name="postcode" required pattern="\d{4}">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="email">Email Address *</label>
              <input type="email" id="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" placeholder="example@email.com" required>
            </div>
            <div class="form-group">
              <label for="phone">Phone Number *</label>
              <input type="text" id="phone" name="phone" required pattern="[0-9\s]{8,12}">
            </div>
          </div>
        </fieldset>
        
        <!-- Skills Section -->
        <fieldset>
          <legend>Skills *</legend>
          <div class="skills-container">
            <label><input type="checkbox" name="skills[]" value="Communication"> Communication</label>
            <label><input type="checkbox" name="skills[]" value="Teamwork"> Teamwork</label>
            <label><input type="checkbox" name="skills[]" value="Problem Solving"> Problem Solving</label>
            <label><input type="checkbox" name="skills[]" value="Other"> Other skills...</label>
            <div class="text-box">
              <label for="otherskills">Other skills (optional)</label>
              <textarea id="otherskills" name="otherskills" placeholder="Please specify other skills"></textarea>
            </div>
            
          </div>
        </fieldset>
        
        <!-- Form Buttons -->
        <div class="form-buttons">
          <input type="submit" value="Apply">
          <input type="reset" value="Reset">
        </div>
      </form>
    </div>
  </main>

<?php
include_once "footer.inc";
?>
</body>
</html>